package dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

public class UpdateMemberDAO {

	private static final String URL = "jdbc:mysql://localhost/sql_training";
	private static final String USER = "root";
	private static final String PASSWORD = "";

	//メンバー情報を変更する処理
	public int updateMember(String password,int id,String name,int age,String address) {

		String sql= "UPDATE member SET name=?,age=?,address=?,password=? WHERE id=?";

		Connection con = null;
		PreparedStatement ps = null;

		int result = -1;

		try {
			//DBに接続
			Class.forName("com.mysql.cj.jdbc.Driver");
			con = DriverManager.getConnection(URL, USER, PASSWORD);
			//スタートメントを生成
			ps = con.prepareStatement(sql);
			//?に値をセット
			ps.setString(1,name);
			ps.setInt(2,age);
			ps.setString(3,address);
			ps.setString(4,password);
			ps.setInt(5,id);
			result = ps.executeUpdate();

		}catch (Exception e) {
			e.printStackTrace();
		} finally {
			//リソースを解放
			try {
				if(ps != null) ps.close();
				if(con != null) con.close();
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		return result;
	}

	//解答した履歴をDBへ格納する処理
	public int updateResultBasic(int id,String P1,String P2,String P3,String P4) {

		String sql= "UPDATE result_basic SET P1=?,P2=?,P3=?,P4=? WHERE id=?";

		Connection con = null;
		PreparedStatement ps = null;

		int result = -1;

		try {
			//DBに接続
			Class.forName("com.mysql.cj.jdbc.Driver");
			con = DriverManager.getConnection(URL, USER, PASSWORD);
			//スタートメントを生成
			ps = con.prepareStatement(sql);
			//?に値をセット
			ps.setString(1,P1);
			ps.setString(2,P2);
			ps.setString(3,P3);
			ps.setString(4,P4);
			ps.setInt(5,id);
			result = ps.executeUpdate();

		}catch (Exception e) {
			e.printStackTrace();
		} finally {
			//リソースを解放
			try {
				if(ps != null) ps.close();
				if(con != null) con.close();
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		return result;
	}

	//解答履歴リセットボタンからリセットする処理
	public int updateresult_basic(int id) {

		String sql="UPDATE result_basic SET P1='-',P2='-',P3='-',P4='-' WHERE id=?";

		Connection con = null;
		PreparedStatement ps = null;
		int result = -1;

		try {
			//DBに接続
			Class.forName("com.mysql.cj.jdbc.Driver");
			con = DriverManager.getConnection(URL, USER, PASSWORD);
			//スタートメントを生成
			ps = con.prepareStatement(sql);
			//?に値をセット
			ps.setInt(1,id);
			result = ps.executeUpdate();

		}catch (Exception e) {
			e.printStackTrace();
		} finally {
			//リソースを解放
			try {
				if(ps != null) ps.close();
				if(con != null) con.close();
			} catch (Exception e) {
				e.printStackTrace();
			}
		}return result;
	}
}
