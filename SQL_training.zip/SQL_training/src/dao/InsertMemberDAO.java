package dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import entity.Member;

public class InsertMemberDAO {

	private static final String URL = "jdbc:mysql://localhost/sql_training";
	private static final String USER = "root";
	private static final String PASSWORD = "";

	//新規会員登録
	public int insertMember(String password,String name,int age,String address) {

		String sql="INSERT INTO member(name,age,address,password) VALUES(?,?,?,?)";

		Connection con = null;
		PreparedStatement ps = null;

		int result = -1;

		try {
			//DBに接続
			Class.forName("com.mysql.cj.jdbc.Driver");
			con = DriverManager.getConnection(URL, USER, PASSWORD);
			//スタートメントを生成
			ps = con.prepareStatement(sql);
			//?に値をセット
			ps.setString(1,name);		//名前
			ps.setInt(2,age);			//年齢
			ps.setString(3,address);	//住所
			ps.setString(4,password);	//パスワード
			result = ps.executeUpdate();

		}catch (Exception e) {
			e.printStackTrace();
		} finally {
			//リソースを解放
			try {
				if(ps != null) ps.close();
				if(con != null) con.close();
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		return result;
	}

	//新規登録したIDを取得する
	public Member insertserchByMember(String password,String name){

		String sql="SELECT * FROM member WHERE password=? AND name=?";

		Connection con = null;
		PreparedStatement ps = null;
		ResultSet rs = null;

		Member member = null;

		try {
			//DBに接続
			Class.forName("com.mysql.cj.jdbc.Driver");
			con = DriverManager.getConnection(URL, USER, PASSWORD);
			//スタートメントを生成
			ps = con.prepareStatement(sql);
			//?に値をセット
			ps.setString(1,password);
			ps.setString(2,name);
			//実行メソッド。結果がrsに受け取る
			rs = ps.executeQuery();
			//rsからデータを取り出す
			if(rs.next()) {
				//rsにて取得した結果をエンティティに格納する。
				member = new Member(); //インスタンスを生成
				member.setId(rs.getInt("id"));
				member.setPassword(rs.getString("password"));
				member.setName(rs.getString("name"));
				member.setAge(rs.getInt("age"));
				member.setAddress(rs.getString("address"));
			}
		}catch (Exception e) {
			e.printStackTrace();
		} finally {
			//リソースを解放
			try {
				if(rs != null) rs.close();
				if(ps != null) ps.close();
				if(con != null) con.close();
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		return member;

	}

	//解答履歴の新規作成
	public int insertserchByResult_basic(int id){

		String sql="INSERT INTO result_basic(id,P1,P2,P3,P4,P5,P6,P7,P8,P9,P10) VALUES(?,'-','-','-','-','-','-','-','-','-','-')";

		Connection con = null;
		PreparedStatement ps = null;

		int result = -1;

		try {
			//DBに接続
			Class.forName("com.mysql.cj.jdbc.Driver");
			con = DriverManager.getConnection(URL, USER, PASSWORD);
			//スタートメントを生成
			ps = con.prepareStatement(sql);
			//?に値をセット
			ps.setInt(1,id);		//名前

			result = ps.executeUpdate();

		}catch (Exception e) {
			e.printStackTrace();
		} finally {
			//リソースを解放
			try {
				if(ps != null) ps.close();
				if(con != null) con.close();
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		return result;
	}
}