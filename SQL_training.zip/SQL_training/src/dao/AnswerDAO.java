package dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import entity.Exercises;

public class AnswerDAO {

	//基本問題1・2・3の解答
	public List<Exercises> serchsql123(String sql) {

		List<Exercises> listAnswer = new ArrayList<Exercises>();

		final String URL = "jdbc:mysql://localhost/sql_training";
		final String USER = "root";
		final String PASSWORD = "";

		Connection con = null;
		Statement st = null;
		ResultSet rs = null;

		Exercises exercises = null;

		try {
			//DBに接続
			Class.forName("com.mysql.cj.jdbc.Driver");
			con = DriverManager.getConnection(URL, USER, PASSWORD);
			//スタートメントを生成
			st = con.createStatement();
			rs = st.executeQuery(sql);

			while(rs.next()) {
				//データを1レコードずつエンティティに格納する
				exercises = new Exercises();
				exercises.setCo_id(rs.getInt("co_id"));
				exercises.setCo_name(rs.getString("co_name"));
				exercises.setCo_location(rs.getString("co_location"));
				listAnswer.add(exercises);
			}
		}catch (Exception e) {
			e.printStackTrace();
		} finally {
			//リソースを解放
			try {
				st.close();
				con.close();
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		return listAnswer;
	}

	//基本問題4・5の解答
	public List<Exercises> serchsql45(String sql) {

		List<Exercises> listAnswer = new ArrayList<Exercises>();

		final String URL = "jdbc:mysql://localhost/sql_training";
		final String USER = "root";
		final String PASSWORD = "";

		Connection con = null;
		Statement st = null;
		ResultSet rs = null;

		Exercises exercises = null;

		try {
			//DBに接続
			Class.forName("com.mysql.cj.jdbc.Driver");
			con = DriverManager.getConnection(URL, USER, PASSWORD);
			//スタートメントを生成
			st = con.createStatement();
			rs = st.executeQuery(sql);

			while(rs.next()) {
				//データを1レコードずつエンティティに格納する
				exercises = new Exercises();
				exercises.setCo_id(rs.getInt("co_id"));
				exercises.setCo_name(rs.getString("co_name"));
				exercises.setName(rs.getString("name"));
				exercises.setAge(rs.getInt("age"));
				exercises.setSex(rs.getString("sex"));
				listAnswer.add(exercises);
			}
		}catch (Exception e) {
			e.printStackTrace();
		} finally {
			//リソースを解放
			try {
				st.close();
				con.close();
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		return listAnswer;
	}
}
