package dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

public class DeleteMemberDAO {

	private static final String URL = "jdbc:mysql://localhost/sql_training";
	private static final String USER = "root";
	private static final String PASSWORD = "";

	public int deleteMember(int id) {

		String sqlMember ="DELETE FROM member WHERE id=?";
		String sqlResult = "DELETE FROM result_basic WHERE id=?";

		Connection conMember = null;
		PreparedStatement psMember = null;

		Connection conResult = null;
		PreparedStatement psResult = null;

		int result = -1;

		try {
			//DBに接続
			Class.forName("com.mysql.cj.jdbc.Driver");
			conMember = DriverManager.getConnection(URL, USER, PASSWORD);
			conResult = DriverManager.getConnection(URL, USER, PASSWORD);

			//スタートメントを生成
			psMember = conMember.prepareStatement(sqlMember);
			//?に値をセット
			psMember.setInt(1,id);
			result = psMember.executeUpdate();

			psResult = conResult.prepareStatement(sqlResult);
			psResult.setInt(1,id);
			result = psResult.executeUpdate();

		}catch (Exception e) {
			e.printStackTrace();
		} finally {
			//リソースを解放
			try {
					psMember.close();
					conMember.close();
					psResult.close();
					conResult.close();

			} catch (Exception e) {
				e.printStackTrace();
			}
		}return result;
	}

}
