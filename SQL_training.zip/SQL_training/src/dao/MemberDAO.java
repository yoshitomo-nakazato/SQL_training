package dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import entity.Member;

public class MemberDAO {

	private static final String URL = "jdbc:mysql://localhost/sql_training";
	private static final String USER = "root";
	private static final String PASSWORD = "";

	//会員ログインした際に行う処理
	public List<Member> serchByMember(int id) {
		List<Member> listM = new ArrayList<Member>();

		String sql="select distinct member.id,name,age,address,password,P1,P2,P3,P4,P5,P6,P7,P8,P9,P10 from member"
				+ " inner join result_basic on member.id=result_basic.id where member.id=?";

		Connection con = null;
		PreparedStatement ps = null;
		ResultSet rs = null;

		Member member = null;

		try {
			//DBに接続
			Class.forName("com.mysql.cj.jdbc.Driver");
			con = DriverManager.getConnection(URL, USER, PASSWORD);
			//スタートメントを生成
			ps = con.prepareStatement(sql);
			//?に値をセット
			ps.setInt(1,id);

			//実行メソッド。結果がrsに受け取る
			rs = ps.executeQuery();
			//rsからデータを取り出す
			if(rs.next()) {
				//rsにて取得した結果をエンティティに格納する。
				member = new Member();
				member.setId(rs.getInt("id"));
				member.setPassword(rs.getString("password"));
				member.setName(rs.getString("name"));
				member.setAge(rs.getInt("age"));
				member.setAddress(rs.getString("address"));
				member.setP1(rs.getString("P1"));
				member.setP2(rs.getString("P2"));
				member.setP3(rs.getString("P3"));
				member.setP4(rs.getString("P4"));
				member.setP5(rs.getString("P5"));
				member.setP6(rs.getString("P6"));
				member.setP7(rs.getString("P7"));
				member.setP8(rs.getString("P8"));
				member.setP9(rs.getString("P9"));
				member.setP10(rs.getString("P10"));
				listM.add(member);
			}
		}catch (Exception e) {
			e.printStackTrace();
		} finally {
			//リソースを解放
			try {
				if(rs != null) rs.close();
				if(ps != null) ps.close();
				if(con != null) con.close();
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		return listM;
	}
}