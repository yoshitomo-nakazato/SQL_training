package dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import entity.Exercises;

public class ExercisesBasicDAO {

	private static final String URL = "jdbc:mysql://localhost/sql_training";
	private static final String USER = "root";
	private static final String PASSWORD = "";

	public List<Exercises> serchCompany() {
		List<Exercises> listCompany = new ArrayList<Exercises>();

		String sql= "SELECT * FROM company";

		Connection con = null;
		PreparedStatement ps = null;
		ResultSet rs = null;

		Exercises exercises = null;

		try {
			//DBに接続
			Class.forName("com.mysql.cj.jdbc.Driver");
			con = DriverManager.getConnection(URL, USER, PASSWORD);
			//スタートメントを生成

			ps = con.prepareStatement(sql);
			rs = ps.executeQuery();

			while(rs.next()) {
				//データを1レコードずつエンティティに格納する
				exercises = new Exercises();
				exercises.setCo_id(rs.getInt("co_id"));
				exercises.setCo_name(rs.getString("co_name"));
				exercises.setCo_location(rs.getString("co_location"));
				listCompany.add(exercises);
			}
		}catch (Exception e) {
			e.printStackTrace();
		} finally {
			//リソースを解放
			try {
					ps.close();
					con.close();

			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		return listCompany;
	}

	public List<Exercises> serchTrainee() {
		List<Exercises> listTrainee = new ArrayList<Exercises>();

		String sql= "SELECT * FROM trainee";

		Connection con = null;
		PreparedStatement ps = null;
		ResultSet rs = null;

		Exercises exercises = null;

		try {
			//DBに接続
			Class.forName("com.mysql.cj.jdbc.Driver");
			con = DriverManager.getConnection(URL, USER, PASSWORD);
			//スタートメントを生成

			ps = con.prepareStatement(sql);
			rs = ps.executeQuery();

			while(rs.next()) {
				//データを1レコードずつエンティティに格納する
				exercises = new Exercises();
				exercises.setId(rs.getInt("id"));
				exercises.setName(rs.getString("name"));
				exercises.setAge(rs.getInt("age"));
				exercises.setSex(rs.getString("sex"));
				exercises.setCo_id(rs.getInt("co_id"));
				listTrainee.add(exercises);
			}
		}catch (Exception e) {
			e.printStackTrace();
		} finally {
			//リソースを解放
			try {
					ps.close();
					con.close();

			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		return listTrainee;
	}

	public List<Exercises> serchUnit() {
		List<Exercises> listUnit = new ArrayList<Exercises>();

		String sql= "SELECT * FROM unit";

		Connection con = null;
		PreparedStatement ps = null;
		ResultSet rs = null;

		Exercises exercises = null;

		try {
			//DBに接続
			Class.forName("com.mysql.cj.jdbc.Driver");
			con = DriverManager.getConnection(URL, USER, PASSWORD);
			//スタートメントを生成

			ps = con.prepareStatement(sql);
			rs = ps.executeQuery();

			while(rs.next()) {
				//データを1レコードずつエンティティに格納する
				exercises = new Exercises();
				exercises.setUnit_id(rs.getInt("co_id"));
				exercises.setUnit_name(rs.getString("co_name"));
				listUnit.add(exercises);
			}
		}catch (Exception e) {
			e.printStackTrace();
		} finally {
			//リソースを解放
			try {
					ps.close();
					con.close();

			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		return listUnit;
	}

}
