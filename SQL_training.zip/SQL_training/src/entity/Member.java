package entity;

public class Member {

	private int id ;			//必須ログインＩＤ
	private String password ;		//必須ログインパスワード

	private String name ;		//必須ＩＤ又はＰＡＳＳの忘れた際に利用
	private int age ;			//任意
	private String address ;		//任意

	private String P1 ;
	private String P2 ;
	private String P3 ;
	private String P4 ;
	private String P5 ;
	private String P6 ;
	private String P7 ;
	private String P8 ;
	private String P9 ;
	private String P10 ;


	public String getP1() {
		return P1;
	}
	public void setP1(String p1) {
		P1 = p1;
	}
	public String getP2() {
		return P2;
	}
	public void setP2(String p2) {
		P2 = p2;
	}
	public String getP3() {
		return P3;
	}
	public void setP3(String p3) {
		P3 = p3;
	}
	public String getP4() {
		return P4;
	}
	public void setP4(String p4) {
		P4 = p4;
	}
	public String getP5() {
		return P5;
	}
	public void setP5(String p5) {
		P5 = p5;
	}
	public String getP6() {
		return P6;
	}
	public void setP6(String p6) {
		P6 = p6;
	}
	public String getP7() {
		return P7;
	}
	public void setP7(String p7) {
		P7 = p7;
	}
	public String getP8() {
		return P8;
	}
	public void setP8(String p8) {
		P8 = p8;
	}
	public String getP9() {
		return P9;
	}
	public void setP9(String p9) {
		P9 = p9;
	}
	public String getP10() {
		return P10;
	}
	public void setP10(String p10) {
		P10 = p10;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
}
