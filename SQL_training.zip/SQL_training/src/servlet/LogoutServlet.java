package servlet;

//PrintWriter
import java.io.IOException;

//GenericServlet
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
//HttpServlet
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

//@WebServlet("/LogoutServlet")
public class LogoutServlet extends HttpServlet {

	@Override
	protected void doPost(HttpServletRequest request,HttpServletResponse response)
		throws ServletException,IOException{

		HttpSession session = request.getSession(false);

		if(session != null) {
			session.invalidate();
		}
		RequestDispatcher rd = request.getRequestDispatcher("./logout.jsp");
		rd.forward(request, response);
	}
}
