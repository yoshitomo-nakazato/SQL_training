package servlet;

//PrintWriter
import java.io.IOException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
//HttpServlet
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import dao.MemberDAO;
import entity.Member;

//@WebServlet("/LoginServlet")
public class LoginServlet extends HttpServlet {

	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		//入力されたidをintに変換
		String idstr = request.getParameter("id");
		//idにnullと空がないことを確認。
		if(idstr==null ||idstr=="") {
			request.setAttribute("message","ID又はパスワードを入力してください。");
			RequestDispatcher rd = request.getRequestDispatcher("./login.jsp");
			rd.forward(request, response);
		}
		int idMember = Integer.parseInt(idstr);

		String passwordstr = request.getParameter("password");
		//passwordにnullと空がないことを確認。
		if(passwordstr==null ||passwordstr=="") {
			request.setAttribute("message","ID又はパスワードを入力してください。");
			RequestDispatcher rd = request.getRequestDispatcher("./login.jsp");
			rd.forward(request, response);
		}

		String message = null;
		String url = null;

		HttpSession session = request.getSession(false); //セッションの生成

		MemberDAO dao = new MemberDAO(); //インスタンスを生成
		//idからメンバー情報を取得する処理
		List<Member> listM = dao.serchByMember(idMember);
		Member member = new Member();

		try {
			for(int i=0;i<listM.size();i++){
				member = listM.get(i);
			}
				Integer id = member.getId();
				String password = member.getPassword();
				String name = member.getName();
				Integer age = member.getAge();
				String address = member.getAddress();
		//取得したメンバー情報のパスワードと入力されたパスワードが一致するか確認
		if (password.equals(passwordstr)) {
			session = request.getSession(true);
			message = "こんにちは " + name + " さん！";
			url = "./memberPage.jsp";
		}else {
			url = "./login.jsp";
			message ="パスワードに誤りがあります。";
		}
		//パスワードが一致していたら、メンバー情報を格納する。
		session.setAttribute("id", id);
		session.setAttribute("password", password);
		session.setAttribute("name", name);
		session.setAttribute("age", age);
		session.setAttribute("address", address);
		session.setAttribute("listM", listM);
		}catch (Exception e) {
			url = "./login.jsp";
			message ="入力されたＩＤでは該当しませんでした。";
		}

		request.setAttribute("message", message);

		RequestDispatcher rd = request.getRequestDispatcher(url);
		rd.forward(request, response);
	}
}
