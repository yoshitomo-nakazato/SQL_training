package servlet;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import dao.DeleteMemberDAO;

//@WebServlet("/DeleteServlet")
public class DeleteServlet extends HttpServlet {

	@Override
	protected void doPost(HttpServletRequest request,HttpServletResponse response)
		throws ServletException,IOException{

		request.setCharacterEncoding("UTF-8");
		HttpSession session = request.getSession(false); //セッションの生成

		Integer id = (Integer)session.getAttribute("id");

		String url = null;
		String message = null;

		DeleteMemberDAO dao = new DeleteMemberDAO();
		int result = dao.deleteMember(id);

		if(result == 1) {
			session.invalidate();
			message = "会員情報の登録を削除（退会）しました。";
			url = "./logout.jsp";
		}else {
			message = "会員情報の登録を削除（退会）に失敗しました。";
			url = "./delete.jsp";
		}

		request.setAttribute("message", message);

		RequestDispatcher rd = request.getRequestDispatcher(url);
		rd.forward(request, response);
	}
}
