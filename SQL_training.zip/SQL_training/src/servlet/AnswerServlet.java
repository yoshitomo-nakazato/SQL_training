package servlet;

//PrintWriter
import java.io.IOException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
//HttpServlet
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import dao.AnswerDAO;
import dao.MemberDAO;
import dao.UpdateMemberDAO;
import entity.Exercises;
import entity.Member;

//@WebServlet("/AnswerCompanyServlet")
public class AnswerServlet extends HttpServlet {

	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		request.setCharacterEncoding("UTF-8");
		String sql = request.getParameter("sql");
		String basic = request.getParameter("basic");

		//解答の結果をＤＢへ格納する為①⇒②に続く
		HttpSession session = request.getSession(true);
		String name = (String)session.getAttribute("name");
		Member member = new Member();
		Integer id = null;
		String P1 = null;
		String P2 = null;
		String P3 = null;
		String P4 = null;
		List<Member> listM = null;
		if(name != null) {
			listM=(List<Member>)session.getAttribute("listM");
			member = listM.get(0);
			id = member.getId();
			P1 = member.getP1();
			P2 = member.getP2();
			P3 = member.getP3();
			P4 = member.getP3();
		}

		//nullエラーの回避する為の処理
		if(sql == null||sql == "") {
			request.setAttribute("message","入力がありませんでした。再度入力してください。");
			if(basic.equals("basic1")) {
				P1 = "×";
			}else if(basic.equals("basic2")) {
				P2 = "×";
			}else if(basic.equals("basic3")) {
				P3 = "×";
			}else if(basic.equals("basic4")) {
				P4 = "×";
			}
		}

		AnswerDAO dao = new AnswerDAO();
		List<Exercises> listAnswer = null;
		String answer = null;

		//例外処理
		try {

			answer = "入力されたコードには、誤りがありました。";

			if(basic.equals("basic1")) {
				P1 = "×";
			}else if(basic.equals("basic2")) {
				P2 = "×";
			}else if(basic.equals("basic3")) {
				P3 = "×";
			}else if(basic.equals("basic4")) {
				P4 = "×";
			}

			//基本問題1の答え
			if(basic.equals("basic1")&&sql.equals("select * from company where co_id=8;")) {
				listAnswer = dao.serchsql123(sql);
				answer = "Is the correct answer！。正解です。";
				P1 = "〇";

			//基本問題2の答え
			}else if(basic.equals("basic2")&&sql.equals("select * from company order by co_id desc;")) {
				listAnswer = dao.serchsql123(sql);
				answer = "Is the correct answer！。正解です。";
				P2 = "〇";

			//基本問題3の答え
			}else if(basic.equals("basic3")&&sql.equals("select * from company;")) {
				listAnswer = dao.serchsql123(sql);
				answer = "Is the correct answer！。正解です。";
				P3= "〇";

			//基本問題4の答え
			}else if(basic.equals("basic4")&&sql.equals("select company.co_id,company.co_name,trainee.name,trainee.age,trainee.sex from company inner join trainee on company.co_id=trainee.co_id;")) {
				listAnswer = dao.serchsql45(sql);
				answer = "Is the correct answer！。正解です。";
				P4 = "〇";
			}

		}catch (Exception e) {
			answer = "入力されたコードには、誤りがありました。";

			if(basic.equals("basic1")) {
				P1 = "×";
			}else if(basic.equals("basic2")) {
				P2 = "×";
			}else if(basic.equals("basic3")) {
				P3 = "×";
			}else if(basic.equals("basic4")) {
				P4 = "×";
			}

		}
		//解答の結果をＤＢへ格納する為の処理②
		if(name != null) {
			UpdateMemberDAO dao1 = new UpdateMemberDAO();
			dao1.updateResultBasic(id,P1,P2,P3,P4);

			//結果を格納した後に再度メンバーリストを取得する。
			MemberDAO dao2 = new MemberDAO();
			listM = dao2.serchByMember(id);
		}

		session.setAttribute("listM",listM);
		request.setAttribute("basic",basic);
		request.setAttribute("answer",answer);
		request.setAttribute("sql",sql);
		request.setAttribute("listAnswer",listAnswer);

		//問題毎に返る場所の分岐
		RequestDispatcher rd=null;
		if(basic.equals("basic1")) {
			 rd = request.getRequestDispatcher("./exercisesBasic.jsp");
		}else if(basic.equals("basic2")){
			 rd = request.getRequestDispatcher("./exercisesBasic2.jsp");
		}else if(basic.equals("basic3")){
			 rd = request.getRequestDispatcher("./exercisesBasic3.jsp");
		}else if(basic.equals("basic4")){
			 rd = request.getRequestDispatcher("./exercisesBasic4.jsp");
		}
		rd.forward(request, response);
	}
}
