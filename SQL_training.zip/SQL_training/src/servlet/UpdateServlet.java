package servlet;

//PrintWriter
import java.io.IOException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
//HttpServlet
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import dao.MemberDAO;
import dao.UpdateMemberDAO;
import entity.Member;

//@WebServlet("/UpdateServlet")
public class UpdateServlet extends HttpServlet {
	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		request.setCharacterEncoding("UTF-8");
		HttpSession session = request.getSession(true); //セッションの生成

		Integer id = (Integer)session.getAttribute("id");
		String password = request.getParameter("password");
		String name = request.getParameter("name");
		String reset = request.getParameter("reset");
		String url = "./memberPage.jsp";

		String message = null;
		UpdateMemberDAO dao = new UpdateMemberDAO();		//インスタンスを生成

		//会員情報を更新する場合の処理
		if(reset == null) {
			//入力されたageをintに変換
			String StringAge = request.getParameter("age");
			Integer age = Integer.parseInt(StringAge);
			String address = request.getParameter("address");

			//nullを除外する為の処理
			if(name==null ||name== "") {
				request.setAttribute("message","名前を入力してください。");
				RequestDispatcher rd = request.getRequestDispatcher("./Update.jsp");
				rd.forward(request, response);
			}else if(password=="" ||password== "") {
				request.setAttribute("message","パスワードを入力してください。");
				RequestDispatcher rd = request.getRequestDispatcher("./Update.jsp");
				rd.forward(request, response);
			}

			int num = dao.updateMember(password,id,name,age,address);
			if(num == 1) {
				message = "会員情報を更新いたしました。";
				session.setAttribute("id", id);
				session.setAttribute("password", password);
				session.setAttribute("name", name);
				session.setAttribute("age", age);
				session.setAttribute("address", address);
			}else {
				message = "更新出来ませんでした。";
			}

		//解答履歴をリセットボタンにてリセットする場合の処理
		}else if(reset != null) {
			url="./exercises.jsp";
			int num = dao.updateresult_basic(id);
			if(num == 1) {
				message = "解答履歴をリセットいたしました。";
				MemberDAO dao2 = new MemberDAO();
				List<Member> listM = dao2.serchByMember(id);
				session.setAttribute("listM", listM);
			}else {
				message = "解答履歴をリセット出来ませんでした。";
			}
		}

		request.setAttribute("message", message);

		RequestDispatcher rd = request.getRequestDispatcher(url);
		rd.forward(request, response);
	}
}
