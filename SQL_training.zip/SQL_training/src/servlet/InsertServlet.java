package servlet;

//PrintWriter
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
//HttpServlet
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import dao.InsertMemberDAO;
import dao.MemberDAO;
import entity.Member;

//@WebServlet("/InsertServlet")
public class InsertServlet extends HttpServlet {

	@Override
	protected void doPost(HttpServletRequest request,HttpServletResponse response)
		throws ServletException,IOException{

		request.setCharacterEncoding("UTF-8");
		HttpSession session = request.getSession(false);

		String password = request.getParameter("password");
		String name = request.getParameter("name");

		//入力されたageをintに変換
		String agestr = request.getParameter("age");
		Integer age = Integer.parseInt(agestr);

		String address = request.getParameter("address");

		String message = null;
		Integer id = null;

		//入力された情報をDBに接続してIDを生成させる処理
		InsertMemberDAO dao = new InsertMemberDAO();
		int result = dao.insertMember(password,name,age,address);

		MemberDAO dao2 = new MemberDAO();
		List<Member> listM = new ArrayList<Member>();

		if(result == 1) {
			message = "ようこそ"+name+"さん！";
			//パスワードと名前から登録IDを取得する処理
			Member member =dao.insertserchByMember(password,name);
			id = member.getId();
			//取得したIDから解答履歴を作成する処理。
			dao.insertserchByResult_basic(id);
			//取得したIDから全ての情報をリストに格納する処理。
			listM = dao2.serchByMember(id);

		}else {
			message = "会員情報を登録できませんでした。";
		}

		request.setAttribute("message", message);
		session.setAttribute("listM", listM);
		session.setAttribute("id", id);
		session.setAttribute("password", password);
		session.setAttribute("name", name);
		session.setAttribute("age", age);
		session.setAttribute("address", address);

		RequestDispatcher rd = request.getRequestDispatcher("./insertConfirm.jsp");
		rd.forward(request, response);
	}
}
