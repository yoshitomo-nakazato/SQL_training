package servlet;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

//@WebServlet("/CheckLoginServlet")
public class CheckLoginServlet extends HttpServlet {

	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		String id = request.getParameter("id");
		String password = request.getParameter("password");

		String message = null;
		String url = null;

		if(id == "" ||id == null) {
			message = "ＩＤ又はパスワードを入力してください";
			url = "./login.jsp";

		}else if(password =="" || password == null) {
			message = "ＩＤ又はパスワードを入力してください";
			url = "./login.jsp";

		}else {
			url = "/SQL_training/LoginServlet";
		}

		request.setAttribute("message", message);

		RequestDispatcher rd = request.getRequestDispatcher(url);
		rd.forward(request, response);

	}
}
