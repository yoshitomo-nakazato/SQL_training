package servlet;

//PrintWriter
import java.io.IOException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
//HttpServlet
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import dao.ExercisesBasicDAO;
import entity.Exercises;

//@WebServlet("/ExercisesServlet")
public class ExercisesServlet extends HttpServlet {

	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		HttpSession session = request.getSession(true); //セッションの生成
		String basic = request.getParameter("basic");

		//問題になるテーブルをDBより取得する為の処理
		ExercisesBasicDAO dao = new ExercisesBasicDAO();
		List<Exercises> listCompany = dao.serchCompany();		//問題1～3で使用
		List<Exercises> listTrainee = dao.serchTrainee();		//問題4～5で使用
		List<Exercises> listUnit = dao.serchTrainee();

		String error = null;
		String url = null;

		if(!listCompany.isEmpty() || listCompany == null) {			 //問題1～3で使用
			if(!listTrainee.isEmpty() || listTrainee == null) {		//問題4～5で使用
				if(!listUnit.isEmpty() || listUnit == null) {		//
					session.setAttribute("listCompany", listCompany);
					session.setAttribute("listTrainee", listTrainee);
					session.setAttribute("listUnit", listUnit);
					switch(basic) {
					case "Basic1":
						url = "./exercisesBasic.jsp";
						break;
					case "Basic2":
						url = "./exercisesBasic2.jsp";
						break;
					case "Basic3":
						url = "./exercisesBasic3.jsp";
						break;
					case "Basic4":
						url = "./exercisesBasic4.jsp";
						break;
					}
				}
			}
		}else {
			error = "重大なエラーが出ました。管理者へ連絡してください。";
			url = "";
			System.out.println("エラーが発生しています。");
		}

		request.setAttribute("error", error);

		RequestDispatcher rd = request.getRequestDispatcher(url);
		rd.forward(request, response);
	}
}
