package filter;

import java.io.IOException;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

//@WebFilter("/SqlFilter")
public class SqlFilter implements Filter {

	@Override
	public void init(FilterConfig config)throws ServletException{}
	@Override
	public void doFilter(ServletRequest request,ServletResponse response,FilterChain chain)
		throws IOException,ServletException{

		HttpServletRequest httpRequest =(HttpServletRequest) request;
		HttpSession session = httpRequest.getSession(true);

		//ゲスト会員でログインしてる場合
		if(request.getParameter("guests") != null) {
			session.setAttribute("id",0000);
			session.setAttribute("password","guests");
			chain.doFilter(request, response);

		//通常会員でログインした場合
		}else if(session.getAttribute("password") != null && session.getAttribute("id") != null){
			chain.doFilter(request, response);

		//ログインせずにアクセスした場合
		}else {
			request.setAttribute("error", "こちらから、ログインしてください。");
			RequestDispatcher rd = request.getRequestDispatcher("./login.jsp");
			rd.forward(request, response);
		}
	}

	@Override
	public void destroy() {}

}